# -*- coding: utf-8 -*-
""" Parcial Javier Agustín Krick
"""

## Regresiones Lineales:

import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
from scipy.optimize import curve_fit

# Definimos la función lineal que utilizaremos para el ajuste
def lineal(x, a, b):
    return a * x + b

# Función para ajustar la curva con incertidumbres
def fit_with_curve(funcion, x, y, y_err):
    popt, pconv = curve_fit(funcion, x, y, sigma=y_err, absolute_sigma=True)
    return popt[0], popt[1], np.sqrt(pconv.diagonal())[0], np.sqrt(pconv.diagonal())[1]

# Cargar los datos desde el archivo CSV
df = pd.read_csv('Jeringa.csv')

# Datos de entrada


df['Presion'] = 99.61*60/df['Volumen']
df['ErrorP'] = df['Presion']*np.sqrt(2)*0.02


variableX = df['Voltaje'] #NombreVariableX
variableY = df['Presion'] #NombreVariableY
incertidumbre_variableY = df['ErrorP'] #NombreVariableErrorY'

# Ajuste de la curva utilizando la función de ajuste personalizada
pendiente, interseccion, error_pendiente, error_interseccion = fit_with_curve(lineal, variableX, variableY, incertidumbre_variableY)

# Cálculo del coeficiente de determinación R^2
R2 = 1 - np.sum((lineal(variableX, pendiente, interseccion) - variableY)**2) / np.sum((variableY - np.mean(variableY))**2)


# Visualización de los datos observados y el ajuste lineal
plt.plot(variableX, variableY, 'o', label='Observaciones')
plt.plot(variableX, lineal(variableX, pendiente, interseccion), label=f"y = {pendiente:.2f} x + {interseccion:.2f}\n"+r"$R^2$"+f" = {R2:.4f}")

# Etiquetas de los ejes
plt.xlabel("Variable X")
plt.ylabel("Variable Y")
plt.legend()
plt.grid()
plt.show()

# Impresión de los parámetros ajustados y sus incertidumbres
print(f"Pendiente = {round(pendiente, 3)} ± {round(error_pendiente, 3)}")
print(f"Intersección = {round(interseccion, 3)} ± {round(error_interseccion, 3)}")

print(round(error_pendiente, 3))


# Calcular los valores ajustados
valores_ajustados = lineal(variableX, pendiente, interseccion)

# Calcular la suma de errores mínimos cuadrados
suma_errores_cuadrados = np.sum((valores_ajustados - variableY)**2)

print("Suma de errores mínimos cuadrados:", suma_errores_cuadrados)



# Calcular los residuos ponderados
residuos_ponderados = (variableY - valores_ajustados) / incertidumbre_variableY

# Calcular la suma de errores cuadráticos mínimos ponderados
suma_errores_ponderados_cuadrados = np.sum(residuos_ponderados**2)

print("Suma de errores cuadráticos mínimos ponderados:", suma_errores_ponderados_cuadrados)



#Ahora tengo que calcular el chi cuadrado reducido que sería exactamente lo mismo pero divido 29
# Ya que tengo 31 grados de libertad y 2 números de parámetros

chiCuadradoReducido = suma_errores_ponderados_cuadrados/29

print("ChiCuadradoReducido es:")
print(chiCuadradoReducido)




print("R2 es")
print(R2)



